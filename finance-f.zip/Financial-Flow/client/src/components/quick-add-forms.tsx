import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { insertIncomeSchema, insertExpenseSchema, insertTaskSchema, insertBillSchema, insertSavingsSchema, insertEmergencyFundSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useCurrency } from "@/hooks/useCurrency";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";

type TabType = "income" | "expense" | "task" | "bill" | "savings" | "emergency";

export default function QuickAddForms() {
  const [activeTab, setActiveTab] = useState<TabType>("income");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { getCurrencySymbol } = useCurrency();

  const incomeForm = useForm({
    resolver: zodResolver(insertIncomeSchema),
    defaultValues: {
      amount: "",
      category: "",
      description: "",
      date: format(new Date(), "yyyy-MM-dd"),
    },
  });

  const expenseForm = useForm({
    resolver: zodResolver(insertExpenseSchema),
    defaultValues: {
      amount: "",
      category: "",
      description: "",
      date: format(new Date(), "yyyy-MM-dd"),
    },
  });

  const taskForm = useForm({
    resolver: zodResolver(insertTaskSchema),
    defaultValues: {
      title: "",
      description: "",
      dueDate: format(new Date(), "yyyy-MM-dd"),
      priority: "medium",
      category: "",
      status: "to-do",
    },
  });

  const billForm = useForm({
    resolver: zodResolver(insertBillSchema),
    defaultValues: {
      amount: "",
      description: "",
      dueDate: format(new Date(), "yyyy-MM-dd"),
      status: "unpaid",
    },
  });

  const savingsForm = useForm({
    resolver: zodResolver(insertSavingsSchema),
    defaultValues: {
      amount: "",
      description: "",
      date: format(new Date(), "yyyy-MM-dd"),
    },
  });

  const emergencyForm = useForm({
    resolver: zodResolver(insertEmergencyFundSchema),
    defaultValues: {
      amount: "",
      description: "",
      date: format(new Date(), "yyyy-MM-dd"),
    },
  });

  const incomeMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/income", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/income"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/daily-pnl"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/monthly-stats"] });
      toast({ title: "Income added successfully" });
      incomeForm.reset();
    },
    onError: () => {
      toast({ title: "Failed to add income", variant: "destructive" });
    },
  });

  const expenseMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/expenses", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/daily-pnl"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/monthly-stats"] });
      toast({ title: "Expense added successfully" });
      expenseForm.reset();
    },
    onError: () => {
      toast({ title: "Failed to add expense", variant: "destructive" });
    },
  });

  const taskMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/tasks", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({ title: "Task added successfully" });
      taskForm.reset();
    },
    onError: () => {
      toast({ title: "Failed to add task", variant: "destructive" });
    },
  });

  const billMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/bills", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      toast({ title: "Bill added successfully" });
      billForm.reset();
    },
    onError: () => {
      toast({ title: "Failed to add bill", variant: "destructive" });
    },
  });

  const savingsMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/savings", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/savings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/monthly-stats"] });
      toast({ title: "Savings added successfully" });
      savingsForm.reset();
    },
    onError: () => {
      toast({ title: "Failed to add savings", variant: "destructive" });
    },
  });

  const emergencyMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/emergency-funds", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-funds"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/monthly-stats"] });
      toast({ title: "Emergency fund added successfully" });
      emergencyForm.reset();
    },
    onError: () => {
      toast({ title: "Failed to add emergency fund", variant: "destructive" });
    },
  });

  const tabConfig = [
    { key: "income", label: "Income", isActive: activeTab === "income" },
    { key: "expense", label: "Expense", isActive: activeTab === "expense" },
    { key: "task", label: "Task", isActive: activeTab === "task" },
    { key: "bill", label: "Bill", isActive: activeTab === "bill" },
    { key: "savings", label: "Savings", isActive: activeTab === "savings" },
    { key: "emergency", label: "Emergency", isActive: activeTab === "emergency" },
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 sm:p-6 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900">Quick Add</h2>
      </div>
      
      {/* Tab Navigation */}
      <div className="border-b border-gray-200">
        <nav className="flex">
          {tabConfig.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as TabType)}
              className={`flex-1 py-3 px-2 sm:px-4 text-center text-xs sm:text-sm font-medium border-b-2 transition-colors ${
                tab.isActive
                  ? "text-primary border-primary bg-primary-light"
                  : "text-gray-500 hover:text-gray-700 border-transparent"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
      
      {/* Forms */}
      <div className="p-4 sm:p-6">
        {activeTab === "income" && (
          <form onSubmit={incomeForm.handleSubmit((data) => incomeMutation.mutate(data))} className="space-y-4">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Amount</Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 text-sm">{getCurrencySymbol()}</span>
                </div>
                <Input
                  {...incomeForm.register("amount")}
                  type="number"
                  step="0.01"
                  className="pl-8"
                  placeholder="0.00"
                />
              </div>
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Category</Label>
              <Input {...incomeForm.register("category")} placeholder="e.g., Salary, Freelance, Investment" />
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Description</Label>
              <Input {...incomeForm.register("description")} placeholder="Enter description" />
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Date</Label>
              <Input {...incomeForm.register("date")} type="date" />
            </div>
            
            <Button type="submit" className="w-full bg-success hover:bg-success-dark text-white" disabled={incomeMutation.isPending}>
              {incomeMutation.isPending ? "Adding..." : "Add Income"}
            </Button>
          </form>
        )}

        {activeTab === "expense" && (
          <form onSubmit={expenseForm.handleSubmit((data) => expenseMutation.mutate(data))} className="space-y-4">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Amount</Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 text-sm">{getCurrencySymbol()}</span>
                </div>
                <Input
                  {...expenseForm.register("amount")}
                  type="number"
                  step="0.01"
                  className="pl-8"
                  placeholder="0.00"
                />
              </div>
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Category</Label>
              <Input {...expenseForm.register("category")} placeholder="e.g., Food & Dining, Transportation" />
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Description</Label>
              <Input {...expenseForm.register("description")} placeholder="Enter description" />
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Date</Label>
              <Input {...expenseForm.register("date")} type="date" />
            </div>
            
            <Button type="submit" className="w-full bg-error hover:bg-error-dark text-white" disabled={expenseMutation.isPending}>
              {expenseMutation.isPending ? "Adding..." : "Add Expense"}
            </Button>
          </form>
        )}

        {activeTab === "task" && (
          <form onSubmit={taskForm.handleSubmit((data) => taskMutation.mutate(data))} className="space-y-4">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Title</Label>
              <Input {...taskForm.register("title")} placeholder="Enter task title" />
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Description</Label>
              <Textarea {...taskForm.register("description")} placeholder="Enter task description" rows={3} />
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Category</Label>
              <Input {...taskForm.register("category")} placeholder="e.g., Work, Personal, Finance" />
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Priority</Label>
              <Select value={taskForm.watch("priority")} onValueChange={(value) => taskForm.setValue("priority", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Due Date</Label>
              <Input {...taskForm.register("dueDate")} type="date" />
            </div>
            
            <Button type="submit" className="w-full bg-primary hover:bg-primary-dark text-white" disabled={taskMutation.isPending}>
              {taskMutation.isPending ? "Adding..." : "Add Task"}
            </Button>
          </form>
        )}

        {activeTab === "bill" && (
          <form onSubmit={billForm.handleSubmit((data) => billMutation.mutate(data))} className="space-y-4">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Amount</Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 text-sm">{getCurrencySymbol()}</span>
                </div>
                <Input
                  {...billForm.register("amount")}
                  type="number"
                  step="0.01"
                  className="pl-8"
                  placeholder="0.00"
                />
              </div>
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Description</Label>
              <Input {...billForm.register("description")} placeholder="e.g., Electric Bill, Internet" />
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Due Date</Label>
              <Input {...billForm.register("dueDate")} type="date" />
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Status</Label>
              <Select value={billForm.watch("status")} onValueChange={(value) => billForm.setValue("status", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="unpaid">Unpaid</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button type="submit" className="w-full bg-warning hover:bg-warning-dark text-white" disabled={billMutation.isPending}>
              {billMutation.isPending ? "Adding..." : "Add Bill"}
            </Button>
          </form>
        )}

        {activeTab === "savings" && (
          <form onSubmit={savingsForm.handleSubmit((data) => savingsMutation.mutate(data))} className="space-y-4">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Amount</Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 text-sm">{getCurrencySymbol()}</span>
                </div>
                <Input
                  {...savingsForm.register("amount")}
                  type="number"
                  step="0.01"
                  className="pl-8"
                  placeholder="0.00"
                />
              </div>
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Description</Label>
              <Input {...savingsForm.register("description")} placeholder="Enter description" />
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Date</Label>
              <Input {...savingsForm.register("date")} type="date" />
            </div>
            
            <Button type="submit" className="w-full" disabled={savingsMutation.isPending}>
              {savingsMutation.isPending ? "Adding..." : "Add Savings"}
            </Button>
          </form>
        )}

        {activeTab === "emergency" && (
          <form onSubmit={emergencyForm.handleSubmit((data) => emergencyMutation.mutate(data))} className="space-y-4">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Amount</Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 text-sm">{getCurrencySymbol()}</span>
                </div>
                <Input
                  {...emergencyForm.register("amount")}
                  type="number"
                  step="0.01"
                  className="pl-8"
                  placeholder="0.00"
                />
              </div>
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Description</Label>
              <Input {...emergencyForm.register("description")} placeholder="Enter description" />
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Date</Label>
              <Input {...emergencyForm.register("date")} type="date" />
            </div>
            
            <Button type="submit" className="w-full" disabled={emergencyMutation.isPending}>
              {emergencyMutation.isPending ? "Adding..." : "Add Emergency Fund"}
            </Button>
          </form>
        )}
      </div>
    </div>
  );
}
