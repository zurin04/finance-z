import { useQuery } from "@tanstack/react-query";
import { TrendingUp, DollarSign, CreditCard, Wallet, ShieldCheck, PiggyBank, Shield } from "lucide-react";
import { format } from "date-fns";
import { useCurrency } from "@/hooks/useCurrency";

export default function DashboardOverview() {
  const { formatCurrency } = useCurrency();
  const today = format(new Date(), "yyyy-MM-dd");
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  const { data: dailyPnL } = useQuery({
    queryKey: ["/api/analytics/daily-pnl", { date: today }],
    queryFn: () => fetch(`/api/analytics/daily-pnl?date=${today}`).then(res => res.json()),
  });

  const { data: monthlyStats } = useQuery({
    queryKey: ["/api/analytics/monthly-stats", { year: currentYear, month: currentMonth }],
    queryFn: () => fetch(`/api/analytics/monthly-stats?year=${currentYear}&month=${currentMonth}`).then(res => res.json()),
  });



  // Calculate available spending (5% of total balance minus today's expenses)
  const totalBalance = monthlyStats?.totalBalance || ((monthlyStats?.income || 0) - (monthlyStats?.expenses || 0));
  const dailySpendingLimit = totalBalance * 0.05;
  const todayExpenses = dailyPnL?.expenses || 0;
  const availableSpending = dailySpendingLimit - todayExpenses;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-4 sm:gap-6 mb-8" data-component="dashboard-overview">
      {/* Today's P&L Card */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Today's P&L</p>
            <p className={`text-xl sm:text-2xl font-bold ${dailyPnL?.pnl >= 0 ? 'text-success' : 'text-error'}`}>
              {dailyPnL?.pnl >= 0 ? '+' : ''}{formatCurrency(dailyPnL?.pnl || 0)}
            </p>
          </div>
          <div className="w-10 h-10 sm:w-12 sm:h-12 bg-success-light rounded-lg flex items-center justify-center">
            <TrendingUp className="text-success w-5 h-5 sm:w-6 sm:h-6" />
          </div>
        </div>
      </div>

      {/* Monthly Income */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Monthly Income</p>
            <p className="text-xl sm:text-2xl font-bold text-gray-900">
              {formatCurrency(monthlyStats?.income || 0)}
            </p>
          </div>
          <div className="w-10 h-10 sm:w-12 sm:h-12 bg-primary-light rounded-lg flex items-center justify-center">
            <DollarSign className="text-primary w-5 h-5 sm:w-6 sm:h-6" />
          </div>
        </div>
      </div>

      {/* Monthly Expenses */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Monthly Expenses</p>
            <p className="text-xl sm:text-2xl font-bold text-gray-900">
              {formatCurrency(monthlyStats?.expenses || 0)}
            </p>
          </div>
          <div className="w-10 h-10 sm:w-12 sm:h-12 bg-error-light rounded-lg flex items-center justify-center">
            <CreditCard className="text-error w-5 h-5 sm:w-6 sm:h-6" />
          </div>
        </div>
      </div>

      {/* Total Balance */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Total Balance</p>
            <p className={`text-xl sm:text-2xl font-bold ${totalBalance >= 0 ? 'text-success' : 'text-error'}`}>
              {formatCurrency(totalBalance)}
            </p>
          </div>
          <div className="w-10 h-10 sm:w-12 sm:h-12 bg-success-light rounded-lg flex items-center justify-center">
            <Wallet className="text-success w-5 h-5 sm:w-6 sm:h-6" />
          </div>
        </div>
        <p className="text-xs text-gray-500 mt-2">Total available money</p>
      </div>

      {/* Savings */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Savings</p>
            <p className="text-xl sm:text-2xl font-bold text-blue-600">
              {formatCurrency(monthlyStats?.savings || 0)}
            </p>
          </div>
          <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-100 rounded-lg flex items-center justify-center">
            <PiggyBank className="text-blue-600 w-5 h-5 sm:w-6 sm:h-6" />
          </div>
        </div>
      </div>

      {/* Emergency Fund */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Emergency Fund</p>
            <p className="text-xl sm:text-2xl font-bold text-orange-600">
              {formatCurrency(monthlyStats?.emergencyFund || 0)}
            </p>
          </div>
          <div className="w-10 h-10 sm:w-12 sm:h-12 bg-orange-100 rounded-lg flex items-center justify-center">
            <Shield className="text-orange-600 w-5 h-5 sm:w-6 sm:h-6" />
          </div>
        </div>
      </div>

      {/* Available to Spend (5% daily limit) */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Available to Spend Today</p>
            <p className={`text-xl sm:text-2xl font-bold ${availableSpending >= 0 ? 'text-warning' : 'text-error'}`}>
              {formatCurrency(availableSpending)}
            </p>
          </div>
          <div className={`w-10 h-10 sm:w-12 sm:h-12 ${availableSpending >= 0 ? 'bg-warning-light' : 'bg-error-light'} rounded-lg flex items-center justify-center`}>
            <ShieldCheck className={`${availableSpending >= 0 ? 'text-warning' : 'text-error'} w-5 h-5 sm:w-6 sm:h-6`} />
          </div>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          Daily limit: {formatCurrency(dailySpendingLimit)} | Used: {formatCurrency(todayExpenses)}
        </p>
      </div>
    </div>
  );
}
