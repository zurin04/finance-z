import { users, income, expenses, bills, tasks, goals, notes, savings, emergencyFunds, type User, type InsertUser, type Income, type InsertIncome, type Expense, type InsertExpense, type Bill, type InsertBill, type Task, type InsertTask, type Goal, type InsertGoal, type Note, type InsertNote, type Savings, type InsertSavings, type EmergencyFund, type InsertEmergencyFund } from "@shared/schema";
import { db } from "./db";
import { eq, or, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByEmailOrUsername(emailOrUsername: string): Promise<User | undefined>;
  getUserByWallet(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserProfile(id: number, data: { email?: string; username?: string; name?: string; currency?: string }): Promise<User | undefined>;
  updateUserPassword(id: number, hashedPassword: string): Promise<User | undefined>;
  
  // Income operations
  getAllIncome(): Promise<Income[]>;
  getIncomeByDateRange(startDate: string, endDate: string): Promise<Income[]>;
  createIncome(income: InsertIncome): Promise<Income>;
  updateIncome(id: number, income: Partial<InsertIncome>): Promise<Income | undefined>;
  deleteIncome(id: number): Promise<boolean>;
  
  // Expense operations
  getAllExpenses(): Promise<Expense[]>;
  getExpensesByDateRange(startDate: string, endDate: string): Promise<Expense[]>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: number, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: number): Promise<boolean>;
  
  // Bill operations
  getAllBills(): Promise<Bill[]>;
  getBillsByStatus(status: string): Promise<Bill[]>;
  createBill(bill: InsertBill): Promise<Bill>;
  updateBill(id: number, bill: Partial<InsertBill>): Promise<Bill | undefined>;
  deleteBill(id: number): Promise<boolean>;
  
  // Task operations
  getAllTasks(): Promise<Task[]>;
  getTasksByStatus(status: string): Promise<Task[]>;
  getTasksByDate(date: string): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  
  // Goal operations
  getAllGoals(): Promise<Goal[]>;
  createGoal(goal: InsertGoal): Promise<Goal>;
  updateGoal(id: number, goal: Partial<InsertGoal>): Promise<Goal | undefined>;
  deleteGoal(id: number): Promise<boolean>;
  
  // Note operations
  getAllNotes(): Promise<Note[]>;
  getNotesByCategory(category: string): Promise<Note[]>;
  getNotesByDate(date: string): Promise<Note[]>;
  createNote(note: InsertNote): Promise<Note>;
  updateNote(id: number, note: Partial<InsertNote>): Promise<Note | undefined>;
  deleteNote(id: number): Promise<boolean>;
  
  // Savings operations
  getAllSavings(): Promise<Savings[]>;
  createSavings(savings: InsertSavings): Promise<Savings>;
  updateSavings(id: number, savings: Partial<InsertSavings>): Promise<Savings | undefined>;
  deleteSavings(id: number): Promise<boolean>;
  
  // Emergency Fund operations
  getAllEmergencyFunds(): Promise<EmergencyFund[]>;
  createEmergencyFund(emergencyFund: InsertEmergencyFund): Promise<EmergencyFund>;
  updateEmergencyFund(id: number, emergencyFund: Partial<InsertEmergencyFund>): Promise<EmergencyFund | undefined>;
  deleteEmergencyFund(id: number): Promise<boolean>;
  
  // Analytics
  getDailyPnL(userId: string, date: string): Promise<{ date: string; income: number; expenses: number; pnl: number }>;
  getMonthlyStats(userId: string, year: number, month: number): Promise<{ income: number; expenses: number; pnl: number; savings: number; emergencyFund: number; totalBalance: number }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserByEmailOrUsername(emailOrUsername: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(
      or(eq(users.email, emailOrUsername), eq(users.username, emailOrUsername))
    );
    return user;
  }

  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.walletAddress, walletAddress));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [newUser] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return newUser;
  }

  async updateUserProfile(id: number, data: { email?: string; username?: string; name?: string; currency?: string }): Promise<User | undefined> {
    const updateData: any = { updatedAt: new Date() };
    if (data.email !== undefined) updateData.email = data.email;
    if (data.username !== undefined) updateData.username = data.username;
    if (data.name !== undefined) updateData.name = data.name;
    if (data.currency !== undefined) updateData.currency = data.currency;

    const [updated] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, id))
      .returning();
    return updated;
  }

  async updateUserPassword(id: number, hashedPassword: string): Promise<User | undefined> {
    const [updated] = await db
      .update(users)
      .set({ password: hashedPassword, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return updated;
  }

  // Income operations
  async getAllIncome(): Promise<Income[]> {
    return await db.select().from(income);
  }

  async getIncomeByDateRange(startDate: string, endDate: string): Promise<Income[]> {
    return await db.select().from(income)
      .where(eq(income.date, startDate)); // Simplified for now
  }

  async createIncome(insertIncome: InsertIncome): Promise<Income> {
    const [newIncome] = await db
      .insert(income)
      .values({ ...insertIncome, userId: "1" })
      .returning();
    return newIncome;
  }

  async updateIncome(id: number, updateData: Partial<InsertIncome>): Promise<Income | undefined> {
    const [updated] = await db
      .update(income)
      .set(updateData)
      .where(eq(income.id, id))
      .returning();
    return updated;
  }

  async deleteIncome(id: number): Promise<boolean> {
    const result = await db.delete(income).where(eq(income.id, id));
    return result.rowCount > 0;
  }

  // Expense operations
  async getAllExpenses(): Promise<Expense[]> {
    return await db.select().from(expenses);
  }

  async getExpensesByDateRange(startDate: string, endDate: string): Promise<Expense[]> {
    return await db.select().from(expenses)
      .where(eq(expenses.date, startDate)); // Simplified for now
  }

  async createExpense(insertExpense: InsertExpense): Promise<Expense> {
    const [newExpense] = await db
      .insert(expenses)
      .values({ ...insertExpense, userId: "1" })
      .returning();
    return newExpense;
  }

  async updateExpense(id: number, updateData: Partial<InsertExpense>): Promise<Expense | undefined> {
    const [updated] = await db
      .update(expenses)
      .set(updateData)
      .where(eq(expenses.id, id))
      .returning();
    return updated;
  }

  async deleteExpense(id: number): Promise<boolean> {
    const result = await db.delete(expenses).where(eq(expenses.id, id));
    return result.rowCount > 0;
  }

  // Bill operations
  async getAllBills(): Promise<Bill[]> {
    return await db.select().from(bills);
  }

  async getBillsByStatus(status: string): Promise<Bill[]> {
    return await db.select().from(bills).where(eq(bills.status, status));
  }

  async createBill(insertBill: InsertBill): Promise<Bill> {
    const [newBill] = await db
      .insert(bills)
      .values({ ...insertBill, userId: "1" })
      .returning();
    return newBill;
  }

  async updateBill(id: number, updateData: Partial<InsertBill>): Promise<Bill | undefined> {
    const [updated] = await db
      .update(bills)
      .set(updateData)
      .where(eq(bills.id, id))
      .returning();
    return updated;
  }

  async deleteBill(id: number): Promise<boolean> {
    const result = await db.delete(bills).where(eq(bills.id, id));
    return result.rowCount > 0;
  }

  // Task operations
  async getAllTasks(): Promise<Task[]> {
    return await db.select().from(tasks);
  }

  async getTasksByStatus(status: string): Promise<Task[]> {
    return await db.select().from(tasks).where(eq(tasks.status, status));
  }

  async getTasksByDate(date: string): Promise<Task[]> {
    return await db.select().from(tasks).where(eq(tasks.dueDate, date));
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values({ ...insertTask, userId: "1" })
      .returning();
    return newTask;
  }

  async updateTask(id: number, updateData: Partial<InsertTask>): Promise<Task | undefined> {
    const [updated] = await db
      .update(tasks)
      .set(updateData)
      .where(eq(tasks.id, id))
      .returning();
    return updated;
  }

  async deleteTask(id: number): Promise<boolean> {
    const result = await db.delete(tasks).where(eq(tasks.id, id));
    return result.rowCount > 0;
  }

  // Goal operations
  async getAllGoals(): Promise<Goal[]> {
    return await db.select().from(goals);
  }

  async createGoal(insertGoal: InsertGoal): Promise<Goal> {
    const [newGoal] = await db
      .insert(goals)
      .values({ ...insertGoal, userId: "1" })
      .returning();
    return newGoal;
  }

  async updateGoal(id: number, updateData: Partial<InsertGoal>): Promise<Goal | undefined> {
    const [updated] = await db
      .update(goals)
      .set(updateData)
      .where(eq(goals.id, id))
      .returning();
    return updated;
  }

  async deleteGoal(id: number): Promise<boolean> {
    const result = await db.delete(goals).where(eq(goals.id, id));
    return result.rowCount > 0;
  }

  // Note operations
  async getAllNotes(): Promise<Note[]> {
    return await db.select().from(notes);
  }

  async getNotesByCategory(category: string): Promise<Note[]> {
    return await db.select().from(notes).where(eq(notes.category, category));
  }

  async getNotesByDate(date: string): Promise<Note[]> {
    return await db.select().from(notes).where(eq(notes.noteDate, date));
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const [newNote] = await db
      .insert(notes)
      .values({ ...insertNote, userId: "1" })
      .returning();
    return newNote;
  }

  async updateNote(id: number, updateData: Partial<InsertNote>): Promise<Note | undefined> {
    const [updated] = await db
      .update(notes)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(notes.id, id))
      .returning();
    return updated;
  }

  async deleteNote(id: number): Promise<boolean> {
    const result = await db.delete(notes).where(eq(notes.id, id));
    return result.rowCount > 0;
  }

  // Savings operations
  async getAllSavings(): Promise<Savings[]> {
    return await db.select().from(savings);
  }

  async createSavings(insertSavings: InsertSavings): Promise<Savings> {
    const [newSavings] = await db
      .insert(savings)
      .values({ ...insertSavings, userId: "1" })
      .returning();
    return newSavings;
  }

  async updateSavings(id: number, updateData: Partial<InsertSavings>): Promise<Savings | undefined> {
    const [updated] = await db
      .update(savings)
      .set(updateData)
      .where(eq(savings.id, id))
      .returning();
    return updated;
  }

  async deleteSavings(id: number): Promise<boolean> {
    const result = await db.delete(savings).where(eq(savings.id, id));
    return result.rowCount > 0;
  }

  // Emergency Fund operations
  async getAllEmergencyFunds(): Promise<EmergencyFund[]> {
    return await db.select().from(emergencyFunds);
  }

  async createEmergencyFund(insertEmergencyFund: InsertEmergencyFund): Promise<EmergencyFund> {
    const [newEmergencyFund] = await db
      .insert(emergencyFunds)
      .values({ ...insertEmergencyFund, userId: "1" })
      .returning();
    return newEmergencyFund;
  }

  async updateEmergencyFund(id: number, updateData: Partial<InsertEmergencyFund>): Promise<EmergencyFund | undefined> {
    const [updated] = await db
      .update(emergencyFunds)
      .set(updateData)
      .where(eq(emergencyFunds.id, id))
      .returning();
    return updated;
  }

  async deleteEmergencyFund(id: number): Promise<boolean> {
    const result = await db.delete(emergencyFunds).where(eq(emergencyFunds.id, id));
    return result.rowCount > 0;
  }

  // Analytics
  async getDailyPnL(userId: string, date: string): Promise<{ date: string; income: number; expenses: number; pnl: number }> {
    const dayIncome = await db.select().from(income).where(
      and(eq(income.date, date), eq(income.userId, userId))
    );
    const dayExpenses = await db.select().from(expenses).where(
      and(eq(expenses.date, date), eq(expenses.userId, userId))
    );
    
    const incomeTotal = dayIncome.reduce((sum, item) => sum + parseFloat(item.amount), 0);
    const expenseTotal = dayExpenses.reduce((sum, item) => sum + parseFloat(item.amount), 0);
    
    return {
      date,
      income: incomeTotal,
      expenses: expenseTotal,
      pnl: incomeTotal - expenseTotal
    };
  }

  async getMonthlyStats(userId: string, year: number, month: number): Promise<{ income: number; expenses: number; pnl: number; savings: number; emergencyFund: number; totalBalance: number }> {
    const monthStr = month.toString().padStart(2, '0');
    const yearMonth = `${year}-${monthStr}`;
    
    const monthlyIncome = await db.select().from(income).where(eq(income.userId, userId));
    const monthlyExpenses = await db.select().from(expenses).where(eq(expenses.userId, userId));
    const allSavings = await db.select().from(savings).where(eq(savings.userId, userId));
    const allEmergencyFunds = await db.select().from(emergencyFunds).where(eq(emergencyFunds.userId, userId));
    
    const incomeTotal = monthlyIncome
      .filter(item => item.date.startsWith(yearMonth))
      .reduce((sum, item) => sum + parseFloat(item.amount), 0);
    
    const expenseTotal = monthlyExpenses
      .filter(item => item.date.startsWith(yearMonth))
      .reduce((sum, item) => sum + parseFloat(item.amount), 0);
    
    const savingsTotal = allSavings.reduce((sum, item) => sum + parseFloat(item.amount), 0);
    const emergencyFundTotal = allEmergencyFunds.reduce((sum, item) => sum + parseFloat(item.amount), 0);
    
    const pnl = incomeTotal - expenseTotal;
    const totalBalance = pnl + savingsTotal + emergencyFundTotal;
    
    return {
      income: incomeTotal,
      expenses: expenseTotal,
      pnl,
      savings: savingsTotal,
      emergencyFund: emergencyFundTotal,
      totalBalance
    };
  }
}

// Simple in-memory storage for quick setup
export class MemStorage implements IStorage {
  private users: User[] = [];
  private currentUserId = 1;
  private income: Income[] = [];
  private expenses: Expense[] = [];
  private bills: Bill[] = [];
  private tasks: Task[] = [];
  private goals: Goal[] = [];
  private notes: Note[] = [];
  private savings: Savings[] = [];
  private emergencyFunds: EmergencyFund[] = [];
  private currentIncomeId = 1;
  private currentExpenseId = 1;
  private currentBillId = 1;
  private currentTaskId = 1;
  private currentGoalId = 1;
  private currentNoteId = 1;
  private currentSavingsId = 1;
  private currentEmergencyFundId = 1;

  async getUser(id: number): Promise<User | undefined> {
    return this.users.find(user => user.id === id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return this.users.find(user => user.email === email);
  }

  async getUserByEmailOrUsername(emailOrUsername: string): Promise<User | undefined> {
    return this.users.find(user => 
      user.email === emailOrUsername || user.username === emailOrUsername
    );
  }

  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    return this.users.find(user => user.walletAddress === walletAddress);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const newUser: User = {
      id: this.currentUserId++,
      email: insertUser.email,
      username: insertUser.username || null,
      name: insertUser.name || null,
      password: insertUser.password || null,
      walletAddress: insertUser.walletAddress || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.push(newUser);
    return newUser;
  }

  async updateUserProfile(id: number, data: { email?: string; username?: string; name?: string; currency?: string }): Promise<User | undefined> {
    const index = this.users.findIndex(user => user.id === id);
    if (index === -1) return undefined;

    const user = this.users[index];
    const updatedUser = {
      ...user,
      email: data.email !== undefined ? data.email : user.email,
      username: data.username !== undefined ? data.username : user.username,
      name: data.name !== undefined ? data.name : user.name,
      currency: data.currency !== undefined ? data.currency : user.currency,
      updatedAt: new Date(),
    };

    this.users[index] = updatedUser;
    return updatedUser;
  }

  async updateUserPassword(id: number, hashedPassword: string): Promise<User | undefined> {
    const index = this.users.findIndex(user => user.id === id);
    if (index === -1) return undefined;

    const user = this.users[index];
    const updatedUser = {
      ...user,
      password: hashedPassword,
      updatedAt: new Date(),
    };

    this.users[index] = updatedUser;
    return updatedUser;
  }

  async getAllIncome(): Promise<Income[]> {
    return this.income;
  }

  async getIncomeByDateRange(startDate: string, endDate: string): Promise<Income[]> {
    return this.income.filter(item => item.date >= startDate && item.date <= endDate);
  }

  async createIncome(insertIncome: InsertIncome): Promise<Income> {
    const newIncome: Income = {
      id: this.currentIncomeId++,
      userId: "1", // Default user for now
      amount: insertIncome.amount,
      category: insertIncome.category,
      description: insertIncome.description,
      date: insertIncome.date,
      createdAt: new Date(),
    };
    this.income.push(newIncome);
    return newIncome;
  }

  async updateIncome(id: number, updateData: Partial<InsertIncome>): Promise<Income | undefined> {
    const index = this.income.findIndex(item => item.id === id);
    if (index !== -1) {
      this.income[index] = { ...this.income[index], ...updateData };
      return this.income[index];
    }
    return undefined;
  }

  async deleteIncome(id: number): Promise<boolean> {
    const index = this.income.findIndex(item => item.id === id);
    if (index !== -1) {
      this.income.splice(index, 1);
      return true;
    }
    return false;
  }

  async getAllExpenses(): Promise<Expense[]> {
    return this.expenses;
  }

  async getExpensesByDateRange(startDate: string, endDate: string): Promise<Expense[]> {
    return this.expenses.filter(item => item.date >= startDate && item.date <= endDate);
  }

  async createExpense(insertExpense: InsertExpense): Promise<Expense> {
    const newExpense: Expense = {
      id: this.currentExpenseId++,
      userId: "1",
      amount: insertExpense.amount,
      category: insertExpense.category,
      description: insertExpense.description,
      date: insertExpense.date,
      createdAt: new Date(),
    };
    this.expenses.push(newExpense);
    return newExpense;
  }

  async updateExpense(id: number, updateData: Partial<InsertExpense>): Promise<Expense | undefined> {
    const index = this.expenses.findIndex(item => item.id === id);
    if (index !== -1) {
      this.expenses[index] = { ...this.expenses[index], ...updateData };
      return this.expenses[index];
    }
    return undefined;
  }

  async deleteExpense(id: number): Promise<boolean> {
    const index = this.expenses.findIndex(item => item.id === id);
    if (index !== -1) {
      this.expenses.splice(index, 1);
      return true;
    }
    return false;
  }

  async getAllBills(): Promise<Bill[]> {
    return this.bills;
  }

  async getBillsByStatus(status: string): Promise<Bill[]> {
    return this.bills.filter(bill => bill.status === status);
  }

  async createBill(insertBill: InsertBill): Promise<Bill> {
    const newBill: Bill = {
      id: this.currentBillId++,
      userId: "1",
      amount: insertBill.amount,
      description: insertBill.description,
      status: insertBill.status,
      dueDate: insertBill.dueDate,
      createdAt: new Date(),
    };
    this.bills.push(newBill);
    return newBill;
  }

  async updateBill(id: number, updateData: Partial<InsertBill>): Promise<Bill | undefined> {
    const index = this.bills.findIndex(item => item.id === id);
    if (index !== -1) {
      this.bills[index] = { ...this.bills[index], ...updateData };
      return this.bills[index];
    }
    return undefined;
  }

  async deleteBill(id: number): Promise<boolean> {
    const index = this.bills.findIndex(item => item.id === id);
    if (index !== -1) {
      this.bills.splice(index, 1);
      return true;
    }
    return false;
  }

  async getAllTasks(): Promise<Task[]> {
    return this.tasks;
  }

  async getTasksByStatus(status: string): Promise<Task[]> {
    return this.tasks.filter(task => task.status === status);
  }

  async getTasksByDate(date: string): Promise<Task[]> {
    return this.tasks.filter(task => task.dueDate === date);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const newTask: Task = {
      id: this.currentTaskId++,
      userId: "1",
      title: insertTask.title,
      description: insertTask.description || null,
      category: insertTask.category,
      status: insertTask.status,
      priority: insertTask.priority,
      dueDate: insertTask.dueDate,
      linkedGoalId: insertTask.linkedGoalId || null,
      createdAt: new Date(),
    };
    this.tasks.push(newTask);
    return newTask;
  }

  async updateTask(id: number, updateData: Partial<InsertTask>): Promise<Task | undefined> {
    const index = this.tasks.findIndex(item => item.id === id);
    if (index !== -1) {
      this.tasks[index] = { ...this.tasks[index], ...updateData };
      return this.tasks[index];
    }
    return undefined;
  }

  async deleteTask(id: number): Promise<boolean> {
    const index = this.tasks.findIndex(item => item.id === id);
    if (index !== -1) {
      this.tasks.splice(index, 1);
      return true;
    }
    return false;
  }

  async getAllGoals(): Promise<Goal[]> {
    return this.goals;
  }

  async createGoal(insertGoal: InsertGoal): Promise<Goal> {
    const newGoal: Goal = {
      id: this.currentGoalId++,
      userId: "1",
      title: insertGoal.title,
      targetAmount: insertGoal.targetAmount,
      currentAmount: insertGoal.currentAmount,
      deadline: insertGoal.deadline,
      category: insertGoal.category,
      createdAt: new Date(),
    };
    this.goals.push(newGoal);
    return newGoal;
  }

  async updateGoal(id: number, updateData: Partial<InsertGoal>): Promise<Goal | undefined> {
    const index = this.goals.findIndex(item => item.id === id);
    if (index !== -1) {
      this.goals[index] = { ...this.goals[index], ...updateData };
      return this.goals[index];
    }
    return undefined;
  }

  async deleteGoal(id: number): Promise<boolean> {
    const index = this.goals.findIndex(item => item.id === id);
    if (index !== -1) {
      this.goals.splice(index, 1);
      return true;
    }
    return false;
  }

  // Note operations
  async getAllNotes(): Promise<Note[]> {
    return this.notes;
  }

  async getNotesByCategory(category: string): Promise<Note[]> {
    return this.notes.filter(note => note.category === category);
  }

  async getNotesByDate(date: string): Promise<Note[]> {
    return this.notes.filter(note => note.noteDate === date);
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const newNote: Note = {
      id: this.currentNoteId++,
      userId: "1",
      title: insertNote.title,
      content: insertNote.content,
      category: insertNote.category,
      noteType: insertNote.noteType,
      noteDate: insertNote.noteDate,
      tags: insertNote.tags || [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.notes.push(newNote);
    return newNote;
  }

  async updateNote(id: number, updateData: Partial<InsertNote>): Promise<Note | undefined> {
    const index = this.notes.findIndex(item => item.id === id);
    if (index !== -1) {
      this.notes[index] = { 
        ...this.notes[index], 
        ...updateData,
        updatedAt: new Date()
      };
      return this.notes[index];
    }
    return undefined;
  }

  async deleteNote(id: number): Promise<boolean> {
    const index = this.notes.findIndex(item => item.id === id);
    if (index !== -1) {
      this.notes.splice(index, 1);
      return true;
    }
    return false;
  }

  // Savings operations
  async getAllSavings(): Promise<Savings[]> {
    return this.savings;
  }

  async createSavings(insertSavings: InsertSavings): Promise<Savings> {
    const newSavings: Savings = {
      id: this.currentSavingsId++,
      userId: "1",
      amount: insertSavings.amount,
      description: insertSavings.description,
      date: insertSavings.date,
      createdAt: new Date(),
    };
    this.savings.push(newSavings);
    return newSavings;
  }

  async updateSavings(id: number, updateData: Partial<InsertSavings>): Promise<Savings | undefined> {
    const index = this.savings.findIndex(item => item.id === id);
    if (index !== -1) {
      this.savings[index] = { ...this.savings[index], ...updateData };
      return this.savings[index];
    }
    return undefined;
  }

  async deleteSavings(id: number): Promise<boolean> {
    const index = this.savings.findIndex(item => item.id === id);
    if (index !== -1) {
      this.savings.splice(index, 1);
      return true;
    }
    return false;
  }

  // Emergency Fund operations
  async getAllEmergencyFunds(): Promise<EmergencyFund[]> {
    return this.emergencyFunds;
  }

  async createEmergencyFund(insertEmergencyFund: InsertEmergencyFund): Promise<EmergencyFund> {
    const newEmergencyFund: EmergencyFund = {
      id: this.currentEmergencyFundId++,
      userId: "1",
      amount: insertEmergencyFund.amount,
      description: insertEmergencyFund.description,
      date: insertEmergencyFund.date,
      createdAt: new Date(),
    };
    this.emergencyFunds.push(newEmergencyFund);
    return newEmergencyFund;
  }

  async updateEmergencyFund(id: number, updateData: Partial<InsertEmergencyFund>): Promise<EmergencyFund | undefined> {
    const index = this.emergencyFunds.findIndex(item => item.id === id);
    if (index !== -1) {
      this.emergencyFunds[index] = { ...this.emergencyFunds[index], ...updateData };
      return this.emergencyFunds[index];
    }
    return undefined;
  }

  async deleteEmergencyFund(id: number): Promise<boolean> {
    const index = this.emergencyFunds.findIndex(item => item.id === id);
    if (index !== -1) {
      this.emergencyFunds.splice(index, 1);
      return true;
    }
    return false;
  }

  async getDailyPnL(userId: string, date: string): Promise<{ date: string; income: number; expenses: number; pnl: number }> {
    const dayIncome = this.income.filter(item => item.date === date);
    const totalIncome = dayIncome.reduce((sum, item) => sum + parseFloat(item.amount), 0);

    const dayExpenses = this.expenses.filter(item => item.date === date);
    const totalExpenses = dayExpenses.reduce((sum, item) => sum + parseFloat(item.amount), 0);

    return {
      date,
      income: totalIncome,
      expenses: totalExpenses,
      pnl: totalIncome - totalExpenses,
    };
  }

  async getMonthlyStats(userId: string, year: number, month: number): Promise<{ income: number; expenses: number; pnl: number; savings: number; emergencyFund: number; totalBalance: number }> {
    const monthStr = month.toString().padStart(2, '0');
    const monthlyIncome = this.income.filter(item => item.date.startsWith(`${year}-${monthStr}`));
    const totalIncome = monthlyIncome.reduce((sum, item) => sum + parseFloat(item.amount), 0);

    const monthlyExpenses = this.expenses.filter(item => item.date.startsWith(`${year}-${monthStr}`));
    const totalExpenses = monthlyExpenses.reduce((sum, item) => sum + parseFloat(item.amount), 0);

    const savingsTotal = this.savings.reduce((sum, item) => sum + parseFloat(item.amount), 0);
    const emergencyFundTotal = this.emergencyFunds.reduce((sum, item) => sum + parseFloat(item.amount), 0);
    
    const pnl = totalIncome - totalExpenses;
    const totalBalance = pnl + savingsTotal + emergencyFundTotal;

    return {
      income: totalIncome,
      expenses: totalExpenses,
      pnl,
      savings: savingsTotal,
      emergencyFund: emergencyFundTotal,
      totalBalance
    };
  }
}

export const storage = new DatabaseStorage();
