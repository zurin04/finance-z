# Quick Start - VPS Deployment

## 1. Configure Your Deployment (1 minute)

Edit `deployment-config.sh` and change:
```bash
DOMAIN="your-domain.com"          # Your actual domain
SUBDOMAIN="finance"               # Subdomain for app (finance.yourdomain.com)
APP_PORT="3001"                   # Change if port conflicts
```

## 2. Validate Configuration

```bash
bash deployment-config.sh validate
```

## 3. Deploy (5-10 minutes)

```bash
sudo bash deploy-manual.sh
```

## 4. Setup SSL (1 minute)

```bash
sudo certbot --nginx -d finance.yourdomain.com
```

## That's it! 🎉

Your personal finance tracker is now running at `https://finance.yourdomain.com`

## What Gets Automated:

✅ **Database**: PostgreSQL with auto-generated secure credentials
✅ **User Management**: Dedicated system user created automatically  
✅ **Process Management**: PM2 configured and started
✅ **Web Server**: Nginx reverse proxy configured
✅ **Security**: Firewall rules and security headers
✅ **SSL Ready**: Prepared for SSL certificate installation
✅ **Logging**: Comprehensive logging system
✅ **Backup**: Automated backup capabilities

## What You Configure:

🔧 **Domain**: Your domain or subdomain
🔧 **Port**: Application port (default 3001)
🔧 **SSL**: One command to install certificate

## Multi-App VPS Safe:

- Uses unique ports to avoid conflicts
- Creates dedicated database and user
- Isolated PM2 processes
- Separate Nginx virtual host
- No interference with existing applications

## Management Commands:

```bash
cd /var/www/personal-finance-tracker
./manage-app.sh status    # Check status
./manage-app.sh logs      # View logs
./manage-app.sh restart   # Restart app
./manage-app.sh backup    # Backup database
```

## Credentials Location:

All auto-generated credentials are saved in:
`/var/www/personal-finance-tracker/deployment-credentials.txt`

## Features Included:

- Complete financial tracking (income, expenses, bills)
- Savings and emergency fund management
- Task and goal tracking
- Calendar view with daily P&L
- Responsive mobile design
- Multi-currency support
- Secure authentication
- Real-time dashboard

## Troubleshooting:

If something goes wrong:
```bash
cd /var/www/personal-finance-tracker
./manage-app.sh fix      # Auto-fix common issues
```

## Security Notes:

- Database credentials are auto-generated (32-character secure passwords)
- Application runs on internal port, accessed via Nginx reverse proxy
- SSL certificate provides HTTPS encryption
- Security headers configured in Nginx
- Firewall rules restrict access to necessary ports only

---

**Time to deploy**: ~10 minutes including SSL setup
**Manual configuration**: Just domain and port
**Everything else**: Fully automated