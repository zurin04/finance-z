# Personal Finance Tracker - Subdomain Deployment

## Quick Configuration Guide

Before running the deployment script, edit the **CONFIGURATION SECTION** in `deploy-subdomain.sh`:

### Required Configuration (Lines 19-22)

```bash
# Domain Configuration
DOMAIN="yourdomain.com"           # Replace with your actual domain
SUBDOMAIN="finance"               # Subdomain name (creates finance.yourdomain.com)
APP_PORT="5000"                   # Internal port (change if conflicts exist)
```

### Optional Configuration (Lines 24-26)

```bash
# Advanced Configuration
INSTALL_SSL="true"                # Set to "false" to skip SSL setup
SETUP_FIREWALL="true"             # Set to "false" to skip firewall configuration
```

## Example Configurations

### Example 1: Main Domain
```bash
DOMAIN="example.com"
SUBDOMAIN="finance" 
APP_PORT="5000"
```
**Result:** https://finance.example.com

### Example 2: Personal Domain
```bash
DOMAIN="johndoe.com"
SUBDOMAIN="money"
APP_PORT="5001"
```
**Result:** https://money.johndoe.com

### Example 3: Multiple Apps (avoid conflicts)
```bash
# First app
DOMAIN="mysite.com"
SUBDOMAIN="finance"
APP_PORT="5000"

# Second app (different port)
DOMAIN="mysite.com" 
SUBDOMAIN="budget"
APP_PORT="5001"
```

## Deployment Steps

1. **Configure the script:**
   ```bash
   nano deploy-subdomain.sh
   # Edit lines 19-22 with your values
   ```

2. **Run deployment:**
   ```bash
   sudo chmod +x deploy-subdomain.sh
   sudo ./deploy-subdomain.sh
   ```

3. **Point DNS to your server:**
   - Create an A record for your subdomain
   - Point it to your VPS IP address

## What Gets Automated

✅ **System Setup:** Node.js, PostgreSQL, PM2, Nginx, Certbot
✅ **Database:** Unique database name, user, and secure password
✅ **Application:** Build, deployment, and process management
✅ **Security:** Firewall rules, security headers, SSL certificate
✅ **Management:** Status monitoring, logs, backups, updates

## Conflict Avoidance Features

- **Unique Database Names:** Timestamped to avoid conflicts
- **Unique App Names:** Based on subdomain and timestamp
- **Port Checking:** Validates port availability before deployment
- **User Isolation:** Creates dedicated system user per deployment

## Post-Deployment Management

```bash
cd /var/www/finance-tracker-*
./manage.sh status    # Check application status
./manage.sh logs      # View application logs
./manage.sh restart   # Restart application
./manage.sh backup    # Create database backup
./manage.sh update    # Update and restart application
```

## Troubleshooting

- **Port conflicts:** Change `APP_PORT` to an unused port
- **Domain issues:** Ensure DNS A record points to your server IP
- **SSL issues:** Run manually: `sudo certbot --nginx -d your.domain.com`
- **Database issues:** Check logs with `./manage.sh logs`

---

**Deployment time:** ~10 minutes
**Manual configuration:** Just domain and subdomain
**Zero conflicts:** Fully automated unique naming