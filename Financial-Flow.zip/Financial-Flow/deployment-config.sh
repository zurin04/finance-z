#!/bin/bash

# Personal Finance Tracker - Deployment Configuration
# Edit these values before running deploy-manual.sh

# =============================================================================
# REQUIRED CONFIGURATION - EDIT THESE VALUES
# =============================================================================

# Domain Configuration
DOMAIN="your-domain.com"                    # Your main domain
SUBDOMAIN="finance"                         # Subdomain for the app (finance.your-domain.com)
# OR use full domain: SUBDOMAIN="yourdomain.com" (for main domain)

# Port Configuration
APP_PORT="3001"                            # Port for the application (change if conflicts)

# =============================================================================
# OPTIONAL CONFIGURATION - EDIT IF NEEDED
# =============================================================================

# Application Settings
APP_NAME="personal-finance-tracker"        # Application name (used for PM2 and directories)
INSTALL_SSL="true"                         # Auto-install SSL certificate (true/false)
SETUP_FIREWALL="true"                      # Configure firewall (true/false)

# Database Settings (leave empty for auto-generation)
DB_NAME=""                                 # Empty = auto-generate unique name
DB_USER=""                                 # Empty = auto-generate unique user
DB_PASSWORD=""                             # Empty = auto-generate secure password

# =============================================================================
# SYSTEM CONFIGURATION - USUALLY DON'T NEED TO CHANGE
# =============================================================================

# Paths
APP_DIR="/var/www/$APP_NAME"               # Application directory
NGINX_CONFIG="/etc/nginx/sites-available/$APP_NAME"  # Nginx config path

# Security
SESSION_SECRET=""                          # Empty = auto-generate

# =============================================================================
# VALIDATION
# =============================================================================

validate_config() {
    local errors=0
    
    if [[ "$DOMAIN" == "your-domain.com" ]]; then
        echo "❌ ERROR: Please change DOMAIN from 'your-domain.com' to your actual domain"
        errors=1
    fi
    
    if [[ "$APP_PORT" =~ ^[0-9]+$ ]] && [[ "$APP_PORT" -ge 1024 ]] && [[ "$APP_PORT" -le 65535 ]]; then
        echo "✅ Port $APP_PORT is valid"
    else
        echo "❌ ERROR: APP_PORT must be a number between 1024-65535"
        errors=1
    fi
    
    if [[ "$SUBDOMAIN" == "finance" ]]; then
        echo "✅ Will use subdomain: $SUBDOMAIN.$DOMAIN"
    else
        echo "✅ Will use domain: $SUBDOMAIN"
    fi
    
    if [[ $errors -eq 0 ]]; then
        echo "✅ Configuration is valid!"
        return 0
    else
        echo "❌ Please fix the errors above before deploying"
        return 1
    fi
}

# =============================================================================
# USAGE INFORMATION
# =============================================================================

show_usage() {
    cat << EOF
Personal Finance Tracker - Deployment Configuration

1. Edit the configuration values above
2. Run: bash deployment-config.sh validate
3. Run: bash deploy-manual.sh

Configuration Summary:
- Domain: $SUBDOMAIN.$DOMAIN
- Port: $APP_PORT
- App Directory: $APP_DIR
- SSL: $INSTALL_SSL
- Firewall: $SETUP_FIREWALL

Quick Start:
1. Change DOMAIN to your actual domain
2. Optionally change APP_PORT if it conflicts
3. Run deployment: sudo bash deploy-manual.sh
EOF
}

# =============================================================================
# MAIN SCRIPT
# =============================================================================

case "$1" in
    "validate")
        validate_config
        ;;
    "help"|"--help"|"-h")
        show_usage
        ;;
    *)
        show_usage
        ;;
esac