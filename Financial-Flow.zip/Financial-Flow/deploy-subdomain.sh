#!/bin/bash

# Personal Finance Tracker - Subdomain Deployment Script
# Configurable deployment for subdomains with conflict avoidance

set -e

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# =============================================================================
# CONFIGURATION SECTION - EDIT THESE VALUES
# =============================================================================

# Domain Configuration
DOMAIN="yourdomain.com"           # Your main domain
SUBDOMAIN="finance"               # Subdomain (will create finance.yourdomain.com)
APP_PORT="5000"                   # Internal port for the application

# Advanced Configuration (optional)
INSTALL_SSL="true"                # Set to "false" to skip SSL setup
SETUP_FIREWALL="true"             # Set to "false" to skip firewall configuration

# =============================================================================
# AUTO-GENERATED CONFIGURATION (DO NOT EDIT)
# =============================================================================

FULL_DOMAIN="$SUBDOMAIN.$DOMAIN"
APP_NAME="finance-tracker-$(echo $SUBDOMAIN | tr '.' '-')"
APP_USER="finance_$(date +%s | tail -c 6)"
APP_DIR="/var/www/$APP_NAME"
NGINX_CONFIG="/etc/nginx/sites-available/$APP_NAME"

# Database configuration with unique names
DB_NAME="finance_$(echo $SUBDOMAIN | tr '.' '_')_$(date +%s | tail -c 6)"
DB_USER="finance_user_$(date +%s | tail -c 6)"
DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
SESSION_SECRET=$(openssl rand -base64 32)

# =============================================================================
# VALIDATION AND PREREQUISITES
# =============================================================================

if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root (use sudo)"
   exit 1
fi

if [ "$DOMAIN" = "yourdomain.com" ]; then
    print_error "Please configure your domain in the CONFIGURATION section"
    print_status "Edit lines 19-22 in this script with your actual domain and subdomain"
    exit 1
fi

# Check for port conflicts
if ss -tlnp | grep -q ":$APP_PORT "; then
    print_error "Port $APP_PORT is already in use. Please choose a different port."
    print_status "Edit APP_PORT in the configuration section"
    exit 1
fi

print_success "Starting deployment for $FULL_DOMAIN on port $APP_PORT"

# =============================================================================
# SYSTEM SETUP
# =============================================================================

print_status "Updating system packages..."
apt update && apt upgrade -y

# Install Node.js 20
if ! command -v node &> /dev/null; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
else
    print_success "Node.js already installed: $(node --version)"
fi

# Install PostgreSQL
if ! command -v psql &> /dev/null; then
    print_status "Installing PostgreSQL..."
    apt-get install -y postgresql postgresql-contrib
    systemctl start postgresql
    systemctl enable postgresql
else
    print_success "PostgreSQL already installed"
fi

# Install PM2
if ! command -v pm2 &> /dev/null; then
    print_status "Installing PM2..."
    npm install -g pm2
else
    print_success "PM2 already installed"
fi

# Install Nginx
if ! command -v nginx &> /dev/null; then
    print_status "Installing Nginx..."
    apt-get install -y nginx
    systemctl start nginx
    systemctl enable nginx
else
    print_success "Nginx already installed"
fi

# Install certbot for SSL
if [ "$INSTALL_SSL" = "true" ] && ! command -v certbot &> /dev/null; then
    print_status "Installing Certbot for SSL..."
    apt-get install -y certbot python3-certbot-nginx
fi

# =============================================================================
# USER AND DIRECTORY SETUP
# =============================================================================

print_status "Creating application user: $APP_USER"
if ! id "$APP_USER" &>/dev/null; then
    useradd -m -s /bin/bash $APP_USER
    usermod -aG sudo $APP_USER
fi

print_status "Setting up application directory: $APP_DIR"
mkdir -p $APP_DIR
chown -R $APP_USER:$APP_USER $APP_DIR

# =============================================================================
# AUTOMATED DATABASE SETUP
# =============================================================================

print_status "Setting up PostgreSQL database with automated configuration..."

# Create database and user with proper permissions
sudo -u postgres psql << EOF
-- Drop existing database and user if they exist
DROP DATABASE IF EXISTS $DB_NAME;
DROP USER IF EXISTS $DB_USER;

-- Create new user with password
CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';

-- Create database with proper ownership
CREATE DATABASE $DB_NAME OWNER $DB_USER;

-- Grant all necessary permissions
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
ALTER USER $DB_USER CREATEDB;

-- Connect to the database and grant schema permissions
\c $DB_NAME
GRANT ALL ON SCHEMA public TO $DB_USER;
GRANT USAGE ON SCHEMA public TO $DB_USER;
GRANT CREATE ON SCHEMA public TO $DB_USER;

-- Ensure user can create tables and sequences
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO $DB_USER;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO $DB_USER;

\q
EOF

# Verify database connection
print_status "Verifying database connection..."
if PGPASSWORD=$DB_PASSWORD psql -h localhost -U $DB_USER -d $DB_NAME -c "SELECT 1;" > /dev/null 2>&1; then
    print_success "Database connection successful"
else
    print_error "Database connection failed. Check PostgreSQL configuration."
    exit 1
fi

# =============================================================================
# APPLICATION DEPLOYMENT
# =============================================================================

print_status "Copying application files..."
cp -r ./* $APP_DIR/
chown -R $APP_USER:$APP_USER $APP_DIR

print_status "Creating environment configuration..."
cat > $APP_DIR/.env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME
PORT=$APP_PORT
SESSION_SECRET=$SESSION_SECRET
PGHOST=localhost
PGPORT=5432
PGUSER=$DB_USER
PGPASSWORD=$DB_PASSWORD
PGDATABASE=$DB_NAME
EOF

chown $APP_USER:$APP_USER $APP_DIR/.env
chmod 600 $APP_DIR/.env

print_status "Installing dependencies and building application..."
cd $APP_DIR
sudo -u $APP_USER npm install
sudo -u $APP_USER npm run build
sudo -u $APP_USER npm prune --production

print_status "Setting up database schema..."
sudo -u $APP_USER npx drizzle-kit push

# =============================================================================
# PM2 PROCESS MANAGEMENT
# =============================================================================

print_status "Configuring PM2 process management..."
cat > $APP_DIR/ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: '$APP_NAME',
    script: 'dist/index.js',
    cwd: '$APP_DIR',
    env: {
      NODE_ENV: 'production',
      PORT: $APP_PORT
    },
    instances: 1,
    exec_mode: 'cluster',
    max_memory_restart: '1G',
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true,
    autorestart: true,
    watch: false,
    min_uptime: '10s',
    max_restarts: 10,
    restart_delay: 5000
  }]
};
EOF

chown $APP_USER:$APP_USER $APP_DIR/ecosystem.config.js

# Create logs directory
mkdir -p $APP_DIR/logs
chown -R $APP_USER:$APP_USER $APP_DIR/logs

print_status "Starting application with PM2..."
cd $APP_DIR
sudo -u $APP_USER pm2 start ecosystem.config.js
sudo -u $APP_USER pm2 save

# Setup PM2 startup script
sudo -u $APP_USER pm2 startup | grep -o 'sudo.*' | bash

# =============================================================================
# NGINX REVERSE PROXY
# =============================================================================

print_status "Configuring Nginx reverse proxy..."
cat > $NGINX_CONFIG << EOF
server {
    listen 80;
    server_name $FULL_DOMAIN;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/javascript application/json;

    location / {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
    }

    # Static file caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        proxy_pass http://localhost:$APP_PORT;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF

# Enable site
ln -sf $NGINX_CONFIG /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

# =============================================================================
# FIREWALL CONFIGURATION
# =============================================================================

if [ "$SETUP_FIREWALL" = "true" ]; then
    print_status "Configuring firewall..."
    ufw allow 22/tcp   # SSH
    ufw allow 80/tcp   # HTTP
    ufw allow 443/tcp  # HTTPS
    ufw --force enable
    print_success "Firewall configured (SSH, HTTP, HTTPS allowed)"
fi

# =============================================================================
# SSL CERTIFICATE SETUP
# =============================================================================

if [ "$INSTALL_SSL" = "true" ]; then
    print_status "Setting up SSL certificate..."
    if certbot --nginx -d $FULL_DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN; then
        print_success "SSL certificate installed and configured"
    else
        print_warning "SSL setup failed. You can run this manually later:"
        print_warning "sudo certbot --nginx -d $FULL_DOMAIN"
    fi
fi

# =============================================================================
# MANAGEMENT SCRIPT CREATION
# =============================================================================

print_status "Creating management script..."
cat > $APP_DIR/manage.sh << 'SCRIPT'
#!/bin/bash

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

APP_NAME=$(basename "$PWD")
BACKUP_DIR="/var/backups/$APP_NAME"

case "$1" in
    status)
        echo "=== APPLICATION STATUS ==="
        pm2 status | grep "$APP_NAME" || echo "Application not running"
        echo ""
        echo "=== NGINX STATUS ==="
        sudo nginx -t && echo "Nginx configuration OK"
        echo ""
        echo "=== DATABASE STATUS ==="
        if PGPASSWORD="$PGPASSWORD" psql -h localhost -U "$PGUSER" -d "$PGDATABASE" -c "SELECT 1;" >/dev/null 2>&1; then
            echo "Database connection OK"
        else
            echo "Database connection FAILED"
        fi
        ;;
    logs)
        pm2 logs "$APP_NAME" --lines 50
        ;;
    restart)
        pm2 restart "$APP_NAME"
        echo "Application restarted"
        ;;
    backup)
        sudo mkdir -p "$BACKUP_DIR"
        BACKUP_FILE="$BACKUP_DIR/backup_$(date +%Y%m%d_%H%M%S).sql"
        PGPASSWORD="$PGPASSWORD" pg_dump -h localhost -U "$PGUSER" "$PGDATABASE" > "$BACKUP_FILE"
        echo "Database backup created: $BACKUP_FILE"
        ;;
    update)
        echo "Updating application..."
        git pull || echo "No git repository found"
        npm install
        npm run build
        npm prune --production
        npx drizzle-kit push
        pm2 restart "$APP_NAME"
        echo "Application updated and restarted"
        ;;
    *)
        echo "Management script for Personal Finance Tracker"
        echo "Usage: $0 {status|logs|restart|backup|update}"
        echo ""
        echo "Commands:"
        echo "  status   - Show application and system status"
        echo "  logs     - View application logs"
        echo "  restart  - Restart the application"
        echo "  backup   - Create database backup"
        echo "  update   - Update and restart application"
        ;;
esac
SCRIPT

chmod +x $APP_DIR/manage.sh
chown $APP_USER:$APP_USER $APP_DIR/manage.sh

# =============================================================================
# DEPLOYMENT SUMMARY
# =============================================================================

print_status "Creating deployment credentials file..."
CREDS_FILE="$APP_DIR/deployment-info.txt"
cat > $CREDS_FILE << EOF
=== DEPLOYMENT INFORMATION ===
Generated: $(date)

Application Details:
- Domain: $FULL_DOMAIN
- App Name: $APP_NAME
- App User: $APP_USER
- App Directory: $APP_DIR
- App Port: $APP_PORT (internal)
- SSL: $INSTALL_SSL

Database Details:
- Database Name: $DB_NAME
- Database User: $DB_USER
- Database Password: $DB_PASSWORD

Access URLs:
- HTTP: http://$FULL_DOMAIN
- HTTPS: https://$FULL_DOMAIN (if SSL enabled)

Management Commands:
cd $APP_DIR
./manage.sh status    # Check status
./manage.sh logs      # View logs
./manage.sh restart   # Restart app
./manage.sh backup    # Backup database
./manage.sh update    # Update app

Manual Commands:
- PM2 Status: pm2 status
- Nginx Test: sudo nginx -t
- SSL Renewal: sudo certbot renew

Security Notes:
- Application runs on internal port $APP_PORT
- Only accessible via Nginx reverse proxy
- Database credentials auto-generated
- Firewall configured for SSH, HTTP, HTTPS only

EOF

chmod 600 $CREDS_FILE
chown $APP_USER:$APP_USER $CREDS_FILE

# =============================================================================
# COMPLETION
# =============================================================================

echo ""
echo "========================================"
echo "🎉 DEPLOYMENT COMPLETED SUCCESSFULLY!"
echo "========================================"
echo ""
print_success "Personal Finance Tracker deployed successfully!"
print_status "Application Details:"
echo "   Domain: $FULL_DOMAIN"
echo "   Port: $APP_PORT (internal)"
echo "   SSL: $([ "$INSTALL_SSL" = "true" ] && echo "Enabled" || echo "Disabled")"
echo ""
print_status "Access your application:"
echo "   HTTP:  http://$FULL_DOMAIN"
[ "$INSTALL_SSL" = "true" ] && echo "   HTTPS: https://$FULL_DOMAIN"
echo ""
print_status "Management:"
echo "   cd $APP_DIR && ./manage.sh status"
echo "   cd $APP_DIR && ./manage.sh logs"
echo ""
print_status "Credentials saved to: $CREDS_FILE"
print_warning "Keep your database credentials secure!"
echo ""

if [ "$INSTALL_SSL" != "true" ]; then
    print_warning "To enable SSL later, run:"
    print_warning "sudo certbot --nginx -d $FULL_DOMAIN"
fi

print_success "Deployment complete! Your finance tracker is ready to use."