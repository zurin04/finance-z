import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format, isAfter, isBefore, addDays } from "date-fns";
import { useCurrency } from "@/hooks/useCurrency";
import { CheckCircle, AlertCircle, Clock, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function BillsProgress() {
  const { formatCurrency } = useCurrency();
  const { toast } = useToast();
  const [selectedBill, setSelectedBill] = useState<any>(null);
  const [addAmount, setAddAmount] = useState("");
  const [showAddMoney, setShowAddMoney] = useState(false);
  
  const { data: bills, isLoading } = useQuery({
    queryKey: ["/api/bills"],
    queryFn: () => fetch("/api/bills").then(res => res.json()),
  });

  const addMoneyToBillMutation = useMutation({
    mutationFn: (data: { billId: number; amount: number }) => 
      apiRequest("POST", `/api/bills/${data.billId}/add-money`, { amount: data.amount }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/monthly-stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/daily-pnl"] });
      setShowAddMoney(false);
      setAddAmount("");
      toast({
        title: "Success",
        description: "Bill payment processed successfully!",
      });
    },
    onError: (error: any) => {
      console.error("Error paying bill:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to process bill payment",
        variant: "destructive",
      });
    },
  });

  const handleAddMoney = () => {
    if (selectedBill && addAmount) {
      addMoneyToBillMutation.mutate({
        billId: selectedBill.id,
        amount: parseFloat(addAmount)
      });
    }
  };

  const getBillStatus = (dueDate: string, status: string) => {
    const today = new Date();
    const due = new Date(dueDate);
    const isOverdue = isBefore(due, today) && status === "unpaid";
    const isDueSoon = isAfter(due, today) && isBefore(due, addDays(today, 7)) && status === "unpaid";
    
    if (status === "paid") return "paid";
    if (isOverdue) return "overdue";
    if (isDueSoon) return "due-soon";
    return "pending";
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "paid": return "text-success";
      case "overdue": return "text-error";
      case "due-soon": return "text-warning";
      default: return "text-gray-600";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "paid": return <CheckCircle className="w-4 h-4" />;
      case "overdue": return <AlertCircle className="w-4 h-4" />;
      case "due-soon": return <Clock className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getStatusText = (status: string, dueDate: string) => {
    const due = new Date(dueDate);
    switch (status) {
      case "paid": return "Paid";
      case "overdue": return "Overdue";
      case "due-soon": return "Due Soon";
      default: return `Due ${format(due, "MMM dd")}`;
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Calculate statistics
  const paidBills = bills?.filter((bill: any) => bill.status === "paid") || [];
  const unpaidBills = bills?.filter((bill: any) => bill.status === "unpaid") || [];
  const totalPaid = paidBills.reduce((sum: number, bill: any) => sum + parseFloat(bill.amount), 0);
  const totalUnpaid = unpaidBills.reduce((sum: number, bill: any) => sum + parseFloat(bill.amount), 0);

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 sm:p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Bills Progress</h2>
          <div className="text-sm text-gray-500">
            {paidBills.length} of {bills?.length || 0} paid
          </div>
        </div>
      </div>
      
      <div className="p-4 sm:p-6 space-y-4">
        {/* Summary Statistics */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-success-light p-3 rounded-lg">
            <p className="text-sm text-success font-medium">Paid Bills</p>
            <p className="text-lg font-bold text-success">{formatCurrency(totalPaid)}</p>
          </div>
          <div className="bg-error-light p-3 rounded-lg">
            <p className="text-sm text-error font-medium">Unpaid Bills</p>
            <p className="text-lg font-bold text-error">{formatCurrency(totalUnpaid)}</p>
          </div>
        </div>

        {/* Bills List */}
        {bills && bills.length > 0 ? (
          <div className="space-y-3">
            {bills.map((bill: any) => {
              const billStatus = getBillStatus(bill.dueDate, bill.status);
              const statusColor = getStatusColor(billStatus);
              const statusIcon = getStatusIcon(billStatus);
              
              return (
                <div key={bill.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-gray-900 truncate">{bill.description}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold text-gray-900">
                          {formatCurrency(parseFloat(bill.amount))}
                        </span>
                        {bill.status === "unpaid" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedBill(bill);
                              setShowAddMoney(true);
                            }}
                            className="h-6 px-2"
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                    <div className={`flex items-center gap-2 mt-1 ${statusColor}`}>
                      {statusIcon}
                      <span className="text-sm font-medium">
                        {getStatusText(billStatus, bill.dueDate)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-500 text-sm">No bills to track yet</p>
            <p className="text-gray-400 text-xs mt-1">Add bills using the Quick Add form</p>
          </div>
        )}
      </div>
      
      {/* Add Money Dialog */}
      <Dialog open={showAddMoney} onOpenChange={setShowAddMoney}>
        <DialogContent aria-describedby="pay-bill-description">
          <DialogHeader>
            <DialogTitle>Pay Bill</DialogTitle>
          </DialogHeader>
          <div id="pay-bill-description" className="sr-only">
            Make a payment towards your selected bill
          </div>
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium">Bill: {selectedBill?.description}</p>
              <p className="text-xs text-gray-500">
                Amount: {formatCurrency(parseFloat(selectedBill?.amount || "0"))}
              </p>
              <p className="text-xs text-gray-500">
                Due: {selectedBill?.dueDate ? format(new Date(selectedBill.dueDate), "MMM d, yyyy") : ""}
              </p>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Payment Amount</label>
              <Input
                type="number"
                value={addAmount}
                onChange={(e) => setAddAmount(e.target.value)}
                placeholder="Enter payment amount"
                min="0"
                step="0.01"
              />
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={handleAddMoney}
                disabled={!addAmount || addMoneyToBillMutation.isPending}
                className="flex-1"
              >
                {addMoneyToBillMutation.isPending ? "Processing..." : "Pay Bill"}
              </Button>
              <Button variant="outline" onClick={() => setShowAddMoney(false)}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}