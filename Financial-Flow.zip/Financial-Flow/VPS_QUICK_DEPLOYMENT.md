# Quick VPS Deployment Guide

## Prerequisites
- Ubuntu 20.04+ VPS with sudo access
- Node.js 20+ installed
- PostgreSQL installed and running

## Step-by-Step Deployment

### 1. Clone and Setup
```bash
# Clone your repository
git clone <your-repo-url>
cd Financial-Flow

# Install dependencies
npm install
```

### 2. Database Setup
```bash
# Create database and user
sudo -u postgres psql -c "CREATE DATABASE finance_app;"
sudo -u postgres psql -c "CREATE USER finance_user WITH PASSWORD 'your_secure_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE finance_app TO finance_user;"
```

### 3. Environment Configuration
```bash
# Create .env file
cat > .env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://finance_user:your_secure_password@localhost:5432/finance_app
PGHOST=localhost
PGPORT=5432
PGUSER=finance_user
PGPASSWORD=your_secure_password
PGDATABASE=finance_app
EOF
```

### 4. Build and Deploy
```bash
# Push database schema
npm run db:push

# Build the application
npm run build

# Start with PM2 (recommended)
npm install -g pm2
pm2 start dist/index.js --name "finance-app"
pm2 save
pm2 startup
```

### 5. Nginx Configuration (Optional)
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## Troubleshooting

### If "vite: not found" error occurs:
```bash
# Install dependencies first
npm install

# Then build
npm run build
```

### If database connection fails:
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Test connection
psql -h localhost -U finance_user -d finance_app
```

### If build fails due to memory:
```bash
# Increase Node.js memory limit
export NODE_OPTIONS="--max-old-space-size=4096"
npm run build
```

## Management Commands

```bash
# Check status
pm2 status

# View logs
pm2 logs finance-app

# Restart
pm2 restart finance-app

# Stop
pm2 stop finance-app
```